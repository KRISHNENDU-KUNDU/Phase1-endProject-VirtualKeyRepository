package com.virtualkeyrepository.welcomepage;
import com.virtualkeyrepository.showcurrentfileslist.FileNameList;
import com.virtualkeyrepository.filesuserinterfaces.FunctionalUserInterface;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;

public class WelcomePage implements WelcomeFormat{
	
	private String applicationName = "LockedMe.com";
	private String developerName = "Krishnendu Kundu";
	ArrayList<String> options = new ArrayList();
	
	public WelcomePage(){
		//deafultconstructor
		
		options.add("1.ShowCurrentFilesNameList");
		options.add("2.FunctionalUserInterface");
		options.add("3.Quit");
		
	}
	public void developerInformation() {
		System.out.println(applicationName);
		System.out.println(developerName);
		System.out.println();
		System.out.println();
	}
		
	@Override
	public void show() {
		
		for(String str: this.options) {
			System.out.println(str);
		}
		
	}
	Scanner sc = new Scanner(System.in);
	
	@Override
	public void getUserInput() {
		int menu =0;
		int check = 0;
		while(menu != 3) {
			//System.out.println("Enter Your Choice:");
			//menu = sc.nextInt();
			//this.navigateToMain(menu);
			try {
				System.out.println("Enter Your Choice:");
				menu = sc.nextInt();
				this.navigateToMain(menu);
			
			}
			catch(InputMismatchException e){
				System.out.println("Enter Your Choice:");
				this.show();
				sc.next();
				menu = sc.nextInt();
				this.navigateToMain(menu);
			}
		}
		//if(check == 1) {
			//this.show();
		//}
		}
		
	

	@Override
	public void navigateToMain(int choice) {
		
		switch(choice) {
				
				case 1:
					// To do
					//System.out.println("List of Files");
					FileNameList fnl = new FileNameList();
					fnl.FileDirectory();
					//fnl.printFiles();
					this.show();
					break;
					
				case 2:
					//To do
					FunctionalUserInterface fui = new FunctionalUserInterface();
					fui.show();
					fui.getUserInput();
					
					break;
				
				default:
					if(choice != 3) {
						System.out.println("please Select Valid choice");
						this.show();
					}
					else {
						System.out.println("Application exit with code 0");
					}
					
					break;
					
				}
		
	}
	
	

}
