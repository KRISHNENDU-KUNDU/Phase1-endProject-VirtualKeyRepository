package com.virtualkeyrepository.welcomepage;

public interface WelcomeFormat {
	
	public void show();
	
	public void getUserInput();
	
	public void navigateToMain(int choice);

}
