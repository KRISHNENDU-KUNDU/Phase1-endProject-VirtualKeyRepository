package com.virtualkeyrepository.welcomepage;

public class VirtualKeyRepositoryApplication {

	public static void main(String[] args) {
		
		WelcomePage program = new WelcomePage();
		program.developerInformation();
		program.show();
		try {
		program.getUserInput();
		}
		catch(Exception e) {
			
		}
		//program.navigateToMain();

	}

}
