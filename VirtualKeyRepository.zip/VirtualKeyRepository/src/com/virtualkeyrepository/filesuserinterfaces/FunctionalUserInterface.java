package com.virtualkeyrepository.filesuserinterfaces;

import com.virtualkeyrepository.welcomepage.WelcomeFormat;
import com.virtualkeyrepository.welcomepage.WelcomePage;
import com.virtualkeyrepository.showcurrentfileslist.FileNameList;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.io.*;

public class FunctionalUserInterface implements WelcomeFormat{
	
	ArrayList<String> choice = new ArrayList();
	
	public FunctionalUserInterface(){
		choice.add("1.Add a File");
		choice.add("2.Delete a File");
		choice.add("3.Search a File");
		choice.add("4.Return to  MainContext");
	}

	@Override
	public void show() {
		
		for(String str : choice) {
			System.out.println(str);
		}
		
	}

	@Override
	public void getUserInput() {
		System.out.println("Please enter a choice");
		int menu = 0;
		while(menu != 4) {
			/*
			 * Scanner sc = new Scanner(System.in); menu = sc.nextInt();
			 * this.navigateToMain(menu);
			 */
			/*
			 * try { menu = sc.nextInt(); this.navigateToMain(menu); }
			 * catch(InputMismatchException e) { this.show(); break; }
			 */
			Scanner sc = new Scanner(System.in);
			try {
				System.out.println("Enter Your Choice:");
				menu = sc.nextInt();
				this.navigateToMain(menu);
			
			}
			catch(InputMismatchException e){
				System.out.println("Enter Your Choice:");
				this.show();
				sc.next();
				menu = sc.nextInt();
				this.navigateToMain(menu);
			}
		}
		
		
	}

	@Override
	public void navigateToMain(int choice) {
		
		switch(choice) {
			case 1:
				// Code to Add a File
				this.addFile();
				this.show();
				break;
				
			case 2:
				//Code to Delete a File
				this.deleteFile();
				this.show();
				break;
				
			case 3:
				// Code to search a File
				this.searchFile();
				this.show();
				break;
			case 4:
				//NAVIGATE to the main context
				WelcomePage wp = new WelcomePage();
				wp.show();
				break;
				
			default:
				
					System.out.println("Please give a valid choice ");
					this.show();
				
			}
		
	}
	public void addFile() {
		System.out.println("Enter File name that to be created..");
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();
		String dirName = "src/com/virtualkeyrepository/showcurrentfileslist/";

		
		File dir = new File (dirName);
		File actualFile = new File (dir, fileName);
		
		
		try {
			boolean value = actualFile.createNewFile();
			if(value) {
				System.out.println("Successfully file named "+actualFile+" is created");
				
			}
			else {
				System.out.println("File name already exists");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			
		}
		
	}
	
	public void deleteFile() {
		System.out.println("Enter File name that to be deleted..");
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();
		String dirName = "src/com/virtualkeyrepository/showcurrentfileslist/";

		
		File dir = new File (dirName);
		File file = new File (dir, fileName);
		
		
		try {
			//deletes the file
			boolean value = file.delete();
			if(value) {
				System.out.println("File is deleted");
			}else {
				System.out.println("File does not exist. So, It can not be deleted");
			}
			
		}catch (Exception e) {
			
		}


		
		
	}
	
	public void searchFile() {
		
		
		System.out.println("Enter File name that to be searched..");
		Scanner sc = new Scanner(System.in);
		String fileName = sc.next();
		String dirName = "src/com/virtualkeyrepository/showcurrentfileslist/";
		File dir = new File (dirName);
		File file = new File (dir, fileName);
		int count = 1;
		
		System.out.println("File to search is "+file.getName());
		
		if(dir.exists() && dir.isDirectory() || dir.exists() && dir.isFile()) {
			File[] fileArr = dir.listFiles();
		
		
			for( File f : fileArr) {
				
				if((f.getName()).equals(file.getName())) { 
					  System.out.println("File found"); 
					  count = 0;
				  } 
			}
			
			if(count == 1){
				  System.out.println("There is no file named "+file.getName()+". So, file can not be fetched"); 
				  }
		}
		
		
		
		
	}
	
	

}
