package com.virtualkeyrepository.showcurrentfileslist;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.TreeSet;

public class FileNameList {
	
	
	public void FileDirectory() {
		
			String main_dirPath = "src/com/virtualkeyrepository/showcurrentfileslist/";
					
					//File Object
					File dirpathmain = new File(main_dirPath);
					
					if(dirpathmain.exists() && dirpathmain.isDirectory()||dirpathmain.exists() && dirpathmain.isFile()) {
						//array for files and sub directories
						File fileArr[] = dirpathmain.listFiles();
						
						//System.out.println("Files from the main directory : " + dirpathmain);
						
						
			//add filenames to Tree Set in sorted order
					TreeSet<String> fileNames = new TreeSet<String>();
					for(File f : fileArr) {
						fileNames.add(f.getName());
					}
					System.out.println("File Names in Sorted Order......");
					for(String fname : fileNames) {
						System.out.println(fname);
					}
			
					}

		
	}
	}
	


